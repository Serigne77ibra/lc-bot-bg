const Discord = require("discord.js");

module.exports = {
    run: message => message.channel.send('Salut à toi !'),
    name: 'bjr'
}