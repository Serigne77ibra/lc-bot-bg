const Discord = require("discord.js");

module.exports = {
    run: message => message.channel.send('https://www.youtube.com/channel/UCc0snBmsTZJ16n7C5wxTvZA'),
    name: 'youtube'
}