module.exports = {
    run: message => message.channel.send('Ce site est très chelou'),
    name: 'ph'
}