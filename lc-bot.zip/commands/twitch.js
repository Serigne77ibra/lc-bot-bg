const Discord = require("discord.js");

module.exports = {
    run: message => message.channel.send('https://www.twitch.tv/ILucasCraftI'),
    name: 'twitch'
}